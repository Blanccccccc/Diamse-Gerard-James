On the "Home" page you can see 10 of the most popular and must go historical places in manila I inserted images and short description of the said places.
On the "To Do" page you can see a list of places the user has been already.
On the "About us" you can see the info about the website.
On the "contact us" you can see the contact info of the website admin.
